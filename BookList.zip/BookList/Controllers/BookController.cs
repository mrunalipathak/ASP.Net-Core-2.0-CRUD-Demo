﻿using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookList.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BookList.Controllers
{
    public class BookController : Controller
    {
		private readonly ApplicationDbContext _applicationDbContext;

		public BookController(ApplicationDbContext applicationDbContext)
		{
			_applicationDbContext = applicationDbContext;
		}
        public IActionResult Index()
        {
            return View(_applicationDbContext.Books.ToList());
        }
		//Get : Book/Create
		public IActionResult Create()
		{
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create(Book book)
		{
			if(ModelState.IsValid)
			{
				_applicationDbContext.Add(book);
				await _applicationDbContext.SaveChangesAsync();
				return RedirectToAction("Index");
			}
			return View(book);
		}

		//Details : book/Details/5
		public async Task<IActionResult> Details(int? id)
		{
			if (id == null)
			{
				return NotFound();
			}
			var book = await _applicationDbContext.Books.SingleOrDefaultAsync(m => m.BookID == id);
			if(book == null)
			{
				return NotFound();
			}
			return View(book);

		}

		//Edit : Book/Edit/5
		[HttpGet]
		public async Task<IActionResult> Edit(int? id)
		{
			if (id == null)
			{
				return NotFound();
			}
			var book = await _applicationDbContext.Books.SingleOrDefaultAsync(m => m.BookID == id);
			if (book == null)
			{
				return NotFound();
			}
			return View(book);
		}

		//POST : Book/Edit/5
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(int id, Book book)
		{
			if (id != book.BookID)
			{
				return NotFound();
			}
			if(ModelState.IsValid)
			{
				_applicationDbContext.Update(book);
				await _applicationDbContext.SaveChangesAsync();
				return RedirectToAction(nameof(Index));
			}
			return View(book);
		}

		//Delete : book/delete/5
		public async Task<IActionResult> Delete(int? id)
		{
			if (id == null)
			{
				return NotFound();
			}
			var book = await _applicationDbContext.Books.SingleOrDefaultAsync(m => m.BookID == id);
			if (book == null)
			{
				return NotFound();
			}
			return View(book);
		}

		//POST : Book/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> RemoveBookByID(int id)
		{
			var book = await _applicationDbContext.Books.SingleOrDefaultAsync(m => m.BookID == id);
			_applicationDbContext.Books.Remove(book);
			await _applicationDbContext.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}

		protected override void Dispose(bool disposing)
		{
			if(disposing)
			{
				_applicationDbContext.Dispose();
			}
		}

	}
}
